-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 172.20.0.33    Database: calc_poupanca
-- ------------------------------------------------------
-- Server version	5.6.29-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_calculo`
--

DROP TABLE IF EXISTS `tb_calculo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_calculo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `DT_RLZC_CALCULO` datetime NOT NULL,
  `JR_CRED` decimal(19,2) NOT NULL,
  `JR_RCLMD` decimal(19,2) NOT NULL,
  `NR_AGE` int(11) DEFAULT NULL,
  `NR_CTA` bigint(20) NOT NULL,
  `RMNC_BSCA_CRED` decimal(19,2) NOT NULL,
  `RMNC_BSCA_RCLMD` decimal(19,2) NOT NULL,
  `SD_BASE` decimal(19,2) NOT NULL,
  `TOT_RNDTO_CRED` decimal(19,2) NOT NULL,
  `TOT_RNDTO_RCLMD` decimal(19,2) NOT NULL,
  `VLR_ATLZD_C_MORA` decimal(19,2) NOT NULL,
  `VLR_DIF` decimal(20,20) NOT NULL,
  `VLR_DIF_ATLZD` decimal(19,2) NOT NULL,
  `VLR_FINAL` decimal(19,2) NOT NULL,
  `CD_CLI` int(11) DEFAULT NULL,
  `EXPURGO` int(11) DEFAULT NULL,
  `CD_FUNCI` int(11) DEFAULT NULL,
  `CD_METODOLOGIA` int(11) DEFAULT NULL,
  `CD_PLANO_ECONOMICO` int(11) DEFAULT NULL,
  `CD_PRC` int(11) DEFAULT NULL,
  `ID_HONORARIO` int(11) NOT NULL,
  `ID_MORA` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKk8snfka8d827vyyelhpfqhjfu` (`CD_CLI`),
  KEY `FK5gkjn7w9xfjq87dm5wvabn70d` (`EXPURGO`),
  KEY `FKq1cvii8a5uxecjxjw3ypp3vw1` (`CD_FUNCI`),
  KEY `FKhqx1ltgm2p4ohr080y9sjej84` (`CD_METODOLOGIA`),
  KEY `FK8vd9io7k17v9ckw80lwximgjd` (`CD_PLANO_ECONOMICO`),
  KEY `FKfc9he8vt2gt0rmf7thjef5r0m` (`CD_PRC`),
  KEY `FKdyojkexnwjsprjkc0of0lpl93` (`ID_HONORARIO`),
  KEY `FKgad7epqyxv7q255una9tljqnv` (`ID_MORA`),
  CONSTRAINT `FK5gkjn7w9xfjq87dm5wvabn70d` FOREIGN KEY (`EXPURGO`) REFERENCES `tb_expurgo` (`id`),
  CONSTRAINT `FK8vd9io7k17v9ckw80lwximgjd` FOREIGN KEY (`CD_PLANO_ECONOMICO`) REFERENCES `tb_plano_economico` (`id`),
  CONSTRAINT `FKdyojkexnwjsprjkc0of0lpl93` FOREIGN KEY (`ID_HONORARIO`) REFERENCES `tb_honorario` (`id`),
  CONSTRAINT `FKfc9he8vt2gt0rmf7thjef5r0m` FOREIGN KEY (`CD_PRC`) REFERENCES `tb_protocolo` (`CD_PRC`),
  CONSTRAINT `FKgad7epqyxv7q255una9tljqnv` FOREIGN KEY (`ID_MORA`) REFERENCES `tb_mora` (`id`),
  CONSTRAINT `FKhqx1ltgm2p4ohr080y9sjej84` FOREIGN KEY (`CD_METODOLOGIA`) REFERENCES `tb_metodologia` (`id`),
  CONSTRAINT `FKk8snfka8d827vyyelhpfqhjfu` FOREIGN KEY (`CD_CLI`) REFERENCES `tb_cliente` (`id`),
  CONSTRAINT `FKq1cvii8a5uxecjxjw3ypp3vw1` FOREIGN KEY (`CD_FUNCI`) REFERENCES `tb_funci` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_calculo`
--

LOCK TABLES `tb_calculo` WRITE;
/*!40000 ALTER TABLE `tb_calculo` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_calculo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-05 17:11:26
